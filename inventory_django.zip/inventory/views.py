from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils.dateparse import parse_datetime
from .models import Item
import json, csv
from decimal import Decimal

def inventory_page(request):
    return render(request, "inventory.html")

def parse_decimal(val):
    try:
        return Decimal(str(val))
    except Exception:
        return Decimal("0")

@require_http_methods(["GET", "POST"])
def items_api(request):
    if request.method == "GET":
        qs = Item.objects.all().order_by("-dateAdded")
        items = [{
            "id": str(i.id),
            "barcode": i.barcode,
            "name": i.name,
            "brand": i.brand,
            "model": i.model,
            "qty": i.qty,
            "costPrice": float(i.costPrice),
            "sellPrice": float(i.sellPrice),
            "dateAdded": int(i.dateAdded.timestamp()*1000),
            "extra": i.extra or {},
        } for i in qs]
        return JsonResponse({"items": items})
    # POST create
    try:
        data = json.loads(request.body.decode("utf-8"))
    except Exception:
        return HttpResponseBadRequest("Invalid JSON")
    i = Item(
        barcode=data.get("barcode",""),
        name=data.get("name",""),
        brand=data.get("brand",""),
        model=data.get("model",""),
        qty=int(data.get("qty") or 0),
        costPrice=parse_decimal(data.get("costPrice") or 0),
        sellPrice=parse_decimal(data.get("sellPrice") or 0),
        extra=data.get("extra") or {},
    )
    i.save()
    return JsonResponse({"ok": True, "id": str(i.id)})

@require_http_methods(["GET", "PATCH", "DELETE"])
def item_detail_api(request, item_id):
    it = get_object_or_404(Item, pk=item_id)
    if request.method == "GET":
        return JsonResponse({
            "id": str(it.id),
            "barcode": it.barcode,
            "name": it.name,
            "brand": it.brand,
            "model": it.model,
            "qty": it.qty,
            "costPrice": float(it.costPrice),
            "sellPrice": float(it.sellPrice),
            "dateAdded": int(it.dateAdded.timestamp()*1000),
            "extra": it.extra or {},
        })
    if request.method == "DELETE":
        it.delete()
        return JsonResponse({"ok": True})
    # PATCH update
    try:
        data = json.loads(request.body.decode("utf-8"))
    except Exception:
        return HttpResponseBadRequest("Invalid JSON")
    for f in ["barcode","name","brand","model"]:
        if f in data: setattr(it, f, data[f] or "")
    if "qty" in data: it.qty = int(data["qty"] or 0)
    if "costPrice" in data: it.costPrice = parse_decimal(data["costPrice"] or 0)
    if "sellPrice" in data: it.sellPrice = parse_decimal(data["sellPrice"] or 0)
    if "extra" in data: it.extra = data["extra"] or {}
    it.save()
    return JsonResponse({"ok": True})

def export_json(request):
    items = Item.objects.all().order_by("name")
    payload = [{
        "barcode": i.barcode, "name": i.name, "brand": i.brand, "model": i.model,
        "qty": i.qty, "costPrice": float(i.costPrice), "sellPrice": float(i.sellPrice),
        "dateAdded": int(i.dateAdded.timestamp()*1000), "extra": i.extra or {},
    } for i in items]
    return JsonResponse({"items": payload})

def export_csv(request):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="inventory.csv"'
    writer = csv.writer(response)
    writer.writerow(["barcode","name","brand","model","qty","costPrice","sellPrice","dateAdded"])
    for i in Item.objects.all().order_by("name"):
        writer.writerow([i.barcode, i.name, i.brand, i.model, i.qty, i.costPrice, i.sellPrice, int(i.dateAdded.timestamp()*1000)])
    return response
