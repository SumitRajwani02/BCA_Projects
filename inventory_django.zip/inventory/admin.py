from django.contrib import admin
from .models import Item

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ("name", "barcode", "brand", "model", "qty", "sellPrice", "dateAdded")
    search_fields = ("name", "barcode", "brand", "model")
