from django.db import models
import uuid

class Item(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    barcode = models.CharField(max_length=64, db_index=True, blank=True, default="")
    name = models.CharField(max_length=200, blank=True, default="")
    brand = models.CharField(max_length=120, blank=True, default="")
    model = models.CharField(max_length=120, blank=True, default="")
    qty = models.IntegerField(default=0)
    costPrice = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    sellPrice = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    dateAdded = models.DateTimeField(auto_now_add=True)
    # Extra dynamic columns can be stored as JSON string (kept simple to avoid DB-specific JSON fields)
    extra = models.JSONField(default=dict, blank=True)

    def __str__(self):
        return f"{self.name or '(no name)'}"
