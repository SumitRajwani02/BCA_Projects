from django.urls import path
from . import views

urlpatterns = [
    path("", views.inventory_page, name="inventory_page"),
    # JSON API
    path("api/items/", views.items_api, name="items_api"),
    path("api/items/<uuid:item_id>/", views.item_detail_api, name="item_detail_api"),
    path("api/export.json", views.export_json, name="export_json"),
    path("api/export.csv", views.export_csv, name="export_csv"),
]
