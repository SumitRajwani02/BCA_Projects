# Inventory (Django)

Converted from your static site into a Django app with server-side storage.

## Run
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```
Open http://127.0.0.1:8000

## Files (split 3 ways)
- HTML: `templates/inventory.html`
- CSS:  `static/inventory.css`
- JS:   `static/inventory.js`

## API (used by JS)
- `GET  /api/items/`            → list items
- `POST /api/items/`            → create item (JSON body)
- `GET  /api/items/<id>/`       → get item
- `PATCH/DELETE /api/items/<id>/` → update/delete
- `GET  /api/export.json` and `/api/export.csv`

## Notes
- Settings and custom columns remain in `localStorage` (fast UI); **items** are saved on the server DB.
- Barcode scanner & UI retained. If you want server-side sales tracking or column definitions, tell me and I'll add models.
